function xyt(xlbl,ylbl,ttl)
    xlabel(xlbl);
    ylabel(ylbl);
    title(ttl);
end